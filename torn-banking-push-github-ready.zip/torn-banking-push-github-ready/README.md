# Torn Banking Push — Subscription Portal

This is a multi-faction PWA push notification service for Torn banking scripts.

## What it does

- Any faction leader can create a faction push key from the web page.
- Each new faction gets a free 14-day trial.
- The faction key controls the subscription and countdown.
- A leader can create unlimited banker keys for their faction.
- Each banker uses their own banker key to connect their phone.
- Leaders can list, copy, revoke, and re-enable banker keys.
- If the faction countdown expires, all banker keys stop receiving banking alerts until payment is approved.
- Pricing is **2 Xanax per active banker key every 30 days**.
- Payment claims must match the current active-key price for 30, 60, 90, or 120 days.
- Example: 3 active banker keys costs 6 Xanax for 30 days, 12 for 60, 18 for 90, or 24 for 120.
- Extra approved payments extend the countdown from the current active date.
- Fries91/admin approves payment claims after verifying the item send.

## Key model

There are two types of keys:

```txt
Faction/leader key: tbp_...
- Created by the faction leader.
- Used by the banking backend/script to send alerts.
- Used by the leader to create banker keys.
- Used for countdown/payment status.

Banker key: banker_...
- Created by the leader.
- Given to one banker.
- Used by that banker to connect their phone.
- Can be revoked without changing the main faction key.
```

The leader can make as many banker keys as needed.

## Render setup

Build command:

```bash
pip install -r requirements.txt
```

Start command:

```bash
gunicorn app:app --bind 0.0.0.0:$PORT --workers 1 --threads 8 --timeout 120
```

## Environment variables

Set these in Render:

```txt
APP_NAME=Torn Banking Push
BASE_URL=https://your-render-app.onrender.com
DATABASE_PATH=data/torn_banking_push.sqlite3
ADMIN_PASSWORD=make-a-strong-admin-password
TRIAL_DAYS=14
XANAX_PER_BANKER_KEY_30_DAYS=2
MAX_PAYMENT_MONTHS=4
VAPID_SUBJECT=mailto:your-email@example.com
VAPID_PUBLIC_KEY=generated-public-key
VAPID_PRIVATE_KEY=generated-private-key
```

Generate VAPID keys locally or in Render shell:

```bash
python generate_vapid_keys.py
```

Copy the generated values into Render as `VAPID_PUBLIC_KEY` and `VAPID_PRIVATE_KEY`.

## User flow

1. Faction leader opens the site.
2. They create/get their faction push key.
3. They save the faction key in their Torn banking backend/script.
4. Leader creates one banker key per banker.
5. Each banker opens the same site and connects their phone using their banker key.
6. Banking requests call `/api/banking/request` using the faction key.
7. Phone alerts go only to that faction's connected bankers/leaders/admins.

## Payment flow

1. A faction sends Fries91 Xanax in Torn.
2. They return to this portal.
3. They submit a payment verification claim.
4. Claim must match the faction's active banker-key price.
5. Fries91/admin verifies the Torn item send and approves it.
6. The countdown extends automatically.

Allowed extensions are calculated from active banker keys:

```txt
monthly cost = active banker keys × 2 Xanax
1 month  = monthly cost × 1
2 months = monthly cost × 2
3 months = monthly cost × 3
4 months = monthly cost × 4
```

Example with 5 active banker keys:

```txt
10 Xanax = 30 days
20 Xanax = 60 days
30 Xanax = 90 days
40 Xanax = 120 days
```

## Send banking alert from your Torn banking backend

```python
import requests

requests.post('https://your-render-app.onrender.com/api/banking/request', json={
    'api_token': 'tbp_your_faction_key_here',
    'requester_name': 'Fries91',
    'amount': '$25,000,000',
    'note': 'Vault payout request',
    'url': 'https://your-banking-app.onrender.com'
})
```

If the faction key is expired/locked, the response will be HTTP `402` with:

```json
{
  "ok": false,
  "error": "faction_key_locked"
}
```

## Banker key API

Create a banker key:

```bash
curl -X POST https://your-render-app.onrender.com/api/banker-keys/create \
  -H "Content-Type: application/json" \
  -d '{"api_token":"tbp_faction_key","banker_name":"BankerName","banker_torn_id":"123456"}'
```

List banker keys:

```bash
curl -X POST https://your-render-app.onrender.com/api/banker-keys/list \
  -H "Content-Type: application/json" \
  -d '{"api_token":"tbp_faction_key"}'
```

Revoke a banker key:

```bash
curl -X POST https://your-render-app.onrender.com/api/banker-keys/revoke \
  -H "Content-Type: application/json" \
  -d '{"api_token":"tbp_faction_key","banker_key":"banker_key_here"}'
```

## Admin approval

Open the site, scroll to **Fries91 admin**, enter `ADMIN_PASSWORD`, and click **Show pending payments**.

You can approve or reject claims from there.

## Important

This service does not take payment automatically. Torn item sends are done inside Torn. This app stores a claim, shows proof text, and lets Fries91/admin approve after verification.
